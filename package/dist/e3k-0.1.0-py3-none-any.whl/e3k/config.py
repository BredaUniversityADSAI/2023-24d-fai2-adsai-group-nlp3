config = {
    "subscription_id": "0a94de80-6d3b-49f2-b3e9-ec5818862801",
    "resource_group": "buas-y2",
    "workspace_name": "NLP3",
    "tenant_id": "0a33589b-0036-4fe8-a829-3ed0926af886",
    "client_id": "a2230f31-0fda-428d-8c5c-ec79e91a49f5",
    "client_secret": "Y-q8Q~H63btsUkR7dnmHrUGw2W0gMWjs0MxLKa1C",
}
